# - Game has an opening screen with sound
# - Game greets player
# - Game keeps track of number of guesses
# - Game limits number of guesses
# - Game has different difficulty levels
# - Game does warmer/cooler instead of higher/lower
# - Game has sounds for when you win and run out of guesses
# - Game keeps track of a player's wins and losses
import subprocess
from random import *
print("Welcome!")
subprocess.call(["afplay", "example.wav"])
guess = 0
number = int(randint(1, 100))
i = 1

while True:
    pg = int(input("Guess a number from 1 to 100!"))
    print(number)
    i += 1 # i = i+1
    if pg < number:
        print("Higher!")
    elif pg == number:
        print("Lucky...")
        subprocess.call(["afplay", "dummy.wav"])
        break
        break
    elif pg > number:
        print("Lower!")
    else:
        print("Unrecognized input.")
    if i > 3:
        print("You're really bad at this, I'm gonna have to ask you to leave.")
        subprocess.call(["afplay", "d.wav"])
        break
        break